/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Tim extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Right", "./Tim/costumes/Right.svg", {
        x: 14.685993464654246,
        y: 17.889640026194172
      }),
      new Costume("Left", "./Tim/costumes/Left.svg", {
        x: 14.685988975980251,
        y: 17.889633447777896
      })
    ];

    this.sounds = [new Sound("pop", "./Tim/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(Trigger.BROADCAST, { name: "Reset" }, this.whenIReceiveReset),
      new Trigger(Trigger.BROADCAST, { name: "Up" }, this.whenIReceiveUp),
      new Trigger(Trigger.BROADCAST, { name: "Hj" }, this.whenIReceiveHj),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked5)
    ];
  }

  *whenGreenFlagClicked() {
    yield* this.prepare();
    while (true) {
      yield* this.physics();
      yield;
    }
  }

  *prepare() {
    this.visible = true;
    this.moveAhead();
    this.costume = "Right";
    this.goto(-180, -50);
    this.stage.vars.level = 1;
    this.stage.vars.xv = 0;
    this.stage.vars.yv = 0;
    this.stage.vars.mode = 1;
  }

  *physics() {
    if (this.toNumber(this.stage.vars.mode) === 1) {
      if (this.toNumber(this.stage.vars.InWater) === 1) {
        this.stage.vars.yv += 0.5;
      } else {
        this.stage.vars.yv--;
      }
      if (
        this.keyPressed("left arrow") ||
        this.keyPressed("a") ||
        (this.mouse.down && this.compare(this.x, this.mouse.x) > 0)
      ) {
        this.costume = "Left";
        if (this.toNumber(this.stage.vars.InWater) === 1) {
          this.stage.vars.xv -= 0.2;
        } else {
          this.stage.vars.xv -= 0.8;
        }
      }
      if (
        this.keyPressed("right arrow") ||
        this.keyPressed("d") ||
        (this.mouse.down && this.compare(this.x, this.mouse.x) < 0)
      ) {
        this.costume = "Right";
        if (this.toNumber(this.stage.vars.InWater) === 1) {
          this.stage.vars.xv += 0.2;
        } else {
          this.stage.vars.xv += 0.8;
        }
      }
      this.stage.vars.xv = this.toNumber(this.stage.vars.xv) * 0.9;
      this.x += this.toNumber(this.stage.vars.xv);
      if (this.touching(this.sprites["Ground"].andClones())) {
        this.y += 1;
      }
      if (this.touching(this.sprites["Ground"].andClones())) {
        this.y += 1;
      }
      if (this.touching(this.sprites["Ground"].andClones())) {
        this.y += 1;
      }
      if (this.touching(this.sprites["Ground"].andClones())) {
        this.y += 1;
      }
      if (this.touching(this.sprites["Ground"].andClones())) {
        this.y -= 4;
        this.x += this.toNumber(this.stage.vars.xv) * -1;
        if (
          this.keyPressed("up arrow") ||
          this.keyPressed("w") || this.keyPressed("space") ||
          (this.mouse.down && this.compare(this.mouse.y, this.y) > 0)
        ) {
          this.stage.vars.yv = 10;
          if (
            this.compare(
              Math.abs(this.toNumber(this.stage.vars.xv)),
              this.stage.vars.xv
            ) === 0
          ) {
            this.stage.vars.xv = -5;
          } else {
            this.stage.vars.xv = 5;
          }
        } else {
          this.stage.vars.xv = 0;
        }
      }
      if (this.toNumber(this.stage.vars.InWater) === 1) {
        if (
          this.keyPressed("up arrow") ||
          this.keyPressed("w") || this.keyPressed("space") ||
          (this.mouse.down && this.compare(this.mouse.y, this.y) > 0)
        ) {
          this.stage.vars.yv += 0.5;
        }
      } else {
        this.stage.vars.yv += 0;
      }
      this.y += this.toNumber(this.stage.vars.yv);
      if (this.touching(this.sprites["Ground"].andClones())) {
        this.y += 0 - this.toNumber(this.stage.vars.yv);
        this.stage.vars.yv = 1;
      }
      this.y -= 1;
      if (
        (this.touching(this.sprites["Ground"].andClones()) &&
          (this.keyPressed("up arrow") ||
            this.keyPressed("w") || this.keyPressed("space"))) ||
        (this.touching(this.sprites["Ground"].andClones()) &&
          this.compare(this.y, this.mouse.y) < 0 &&
          this.mouse.down)
      ) {
        this.stage.vars.yv = 15;
      }
      if (
        (this.touching(this.sprites["Water"].andClones()) &&
          (this.keyPressed("up arrow") ||
            this.keyPressed("w") || this.keyPressed("space"))) ||
        (this.touching(this.sprites["Water"].andClones()) &&
          this.compare(this.y, this.mouse.y) < 0 &&
          this.mouse.down)
      ) {
        this.stage.vars.yv = 3;
      }
      this.y += 1;
      if (this.compare(this.y, 180) > 0) {
        this.stage.vars.yv = 0;
      }
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (
        this.keyPressed("r") ||
        this.touching(this.sprites["Bad"].andClones()) ||
        this.compare(-175, this.y) > 0
      ) {
        this.broadcast("Reset");
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.toNumber(this.stage.vars.mode) === 1) {
        if (this.compare(this.x, 235) > 0) {
          this.broadcast("Up");
        }
        if (this.touching(this.sprites["Bounce"].andClones())) {
          this.stage.vars.yv = 21;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked4() {
    while (!(this.toNumber(this.stage.vars.level) === 11)) {
      yield;
    }
    this.stage.vars.mode = 2;
    this.costume = "Right";
    yield* this.glide(1, 165, -112);
  }

  *whenIReceiveReset() {
    this.effects.fisheye = 0;
    this.goto(-180, -50);
    this.stage.vars.lagcheck++;
    yield* this.wait(0.1);
  }

  *whenIReceiveUp() {
    this.stage.vars.level++;
    this.goto(-180, -50);
  }

  *whenIReceiveHj() {
    this.visible = false;
  }

  *whenGreenFlagClicked5() {
    while (true) {
      if (this.toNumber(this.stage.vars.mode) === 1) {
        if (this.touching(this.sprites["Water"].andClones())) {
          if (this.keyPressed("s") || this.keyPressed("down arrow")) {
            this.stage.vars.yv--;
            yield* this.wait(1);
          }
        }
      }
      yield;
    }
  }
}
