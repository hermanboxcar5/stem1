/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Water extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Water/costumes/costume1.svg", { x: 0, y: 0 }),
      new Costume("costume2", "./Water/costumes/costume2.svg", {
        x: 143.375,
        y: 7
      }),
      new Costume("costume3", "./Water/costumes/costume3.svg", { x: 0, y: 0 }),
      new Costume("costume4", "./Water/costumes/costume4.svg", { x: 0, y: 0 }),
      new Costume("costume5", "./Water/costumes/costume5.svg", { x: 0, y: 0 }),
      new Costume("costume6", "./Water/costumes/costume6.svg", { x: 0, y: 0 }),
      new Costume("costume7", "./Water/costumes/costume7.svg", { x: 0, y: 0 }),
      new Costume("costume8", "./Water/costumes/costume8.svg", { x: 0, y: 0 }),
      new Costume("costume9", "./Water/costumes/costume9.svg", { x: 0, y: 0 }),
      new Costume("costume10", "./Water/costumes/costume10.svg", {
        x: 0,
        y: 0
      }),
      new Costume("costume11", "./Water/costumes/costume11.svg", { x: 0, y: 0 })
    ];

    this.sounds = [new Sound("pop", "./Water/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.touching(this.sprites["Tim"].andClones())) {
        this.stage.vars.InWater = 1;
      }
      if (!this.touching(this.sprites["Tim"].andClones())) {
        this.stage.vars.InWater = 0;
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      this.costume = this.stage.vars.level;
      this.goto(0, 0);
      this.moveBehind();
      this.moveBehind();
      this.moveBehind();
      yield;
    }
  }
}
