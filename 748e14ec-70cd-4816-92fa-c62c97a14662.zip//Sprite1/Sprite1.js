/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite1 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite1/costumes/costume1.svg", {
        x: 57.375,
        y: 175
      })
    ];

    this.sounds = [new Sound("pop", "./Sprite1/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.BROADCAST, { name: "Order" }, this.whenIReceiveOrder)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      this.moveAhead();
      this.goto(0, 0);
      if (this.compare(this.stage.vars.lagcheck, 20) > 0) {
        this.stage.vars.lagcheck = 0;
        this.broadcast("Order");
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    this.effects.clear();
    this.visible = false;
    while (true) {
      this.stage.vars.lagcheck = 0;
      yield* this.wait(5);
      yield;
    }
  }

  *whenIReceiveOrder() {
    this.effects.ghost = 100;
    this.visible = true;
    for (let i = 0; i < 10; i++) {
      this.effects.ghost -= 10;
      yield;
    }
    yield* this.wait(5);
    for (let i = 0; i < 10; i++) {
      this.effects.ghost += 10;
      yield;
    }
    this.visible = false;
  }
}
