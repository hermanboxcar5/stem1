/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop2", "./Stage/costumes/backdrop2.svg", { x: 0, y: 0 })
    ];

    this.sounds = [new Sound("recording1", "./Stage/sounds/recording1.wav")];

    this.triggers = [
      new Trigger(Trigger.KEY_PRESSED, { key: "j" }, this.whenKeyJPressed),
      new Trigger(Trigger.KEY_PRESSED, { key: "o" }, this.whenKeyOPressed),
      new Trigger(Trigger.KEY_PRESSED, { key: "p" }, this.whenKeyPPressed),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.KEY_PRESSED, { key: "m" }, this.whenKeyMPressed),
      new Trigger(Trigger.BROADCAST, { name: "Mt" }, this.whenIReceiveMt),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Level.get" },
        this.whenIReceiveLevelGet
      )
    ];

    this.vars.level = 11;
    this.vars.xv = 3.4415777297425474;
    this.vars.yv = 2;
    this.vars.mx = -23;
    this.vars.my = 180;
    this.vars.r = 0;
    this.vars.lagcheck = 0;
    this.vars.l = 0;
    this.vars.u = 0;
    this.vars.mode = 2;
    this.vars.touchscreen = 1;
    this.vars.InWater = 0;
  }

  *whenKeyJPressed() {
    this.broadcast("Level.get");
  }

  *whenKeyOPressed() {
    this.vars.level--;
    this.broadcast("Reset");
  }

  *whenKeyPPressed() {
    this.vars.level++;
    this.broadcast("Reset");
  }

  *whenGreenFlagClicked() {
    this.audioEffects.volume = 100;
    while (true) {
      yield* this.playSoundUntilDone("recording1");
      yield;
    }
  }

  *whenKeyMPressed() {
    this.broadcast("Mt");
  }

  *whenIReceiveMt() {
    this.audioEffects.volume = 0;
  }

  *whenIReceiveLevelGet() {
    yield* this.askAndWait("Enter the number of the level you want to go to");
    if (!(this.toNumber(this.answer) === 0)) {
      this.vars.level = this.answer;
      this.broadcast("Reset");
      this.broadcast("MENU.OFF");
    }
  }
}
