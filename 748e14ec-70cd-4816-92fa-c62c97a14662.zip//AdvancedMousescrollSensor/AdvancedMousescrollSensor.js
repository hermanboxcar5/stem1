/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class AdvancedMousescrollSensor extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "costume1",
        "./AdvancedMousescrollSensor/costumes/costume1.svg",
        { x: 0, y: 0 }
      )
    ];

    this.sounds = [
      new Sound("pop", "./AdvancedMousescrollSensor/sounds/pop.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      this.goto(this.mouse.x, this.mouse.y);
      yield* this.wait(0.01);
      this.stage.vars.mx = this.x;
      this.stage.vars.my = this.y;
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    this.stage.vars.r = 0;
    while (true) {
      if (this.toNumber(this.stage.vars.touchscreen) === 0) {
        if (this.compare(this.mouse.x, this.stage.vars.mx) < 0) {
          this.stage.vars.l = 1;
          while (!!(this.compare(this.mouse.x, this.stage.vars.mx) < 0)) {
            yield;
          }
          this.stage.vars.l = 0;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    this.stage.vars.l = 0;
    while (true) {
      if (this.toNumber(this.stage.vars.touchscreen) === 0) {
        if (this.compare(this.mouse.x, this.stage.vars.mx) > 0) {
          this.stage.vars.r = 1;
          while (!!(this.compare(this.mouse.x, this.stage.vars.mx) > 0)) {
            yield;
          }
          this.stage.vars.r = 0;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked4() {
    this.stage.vars.u = 0;
    while (true) {
      if (this.toNumber(this.stage.vars.touchscreen) === 0) {
        if (this.compare(this.mouse.y, this.stage.vars.my) > 0) {
          this.stage.vars.u = 1;
          while (!!(this.compare(this.mouse.y, this.stage.vars.my) > 0)) {
            yield;
          }
          this.stage.vars.u = 0;
        }
      }
      yield;
    }
  }
}
