/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Bounce extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Bounce/costumes/costume1.svg", { x: 0, y: 0 }),
      new Costume("costume2", "./Bounce/costumes/costume2.svg", { x: 0, y: 0 }),
      new Costume("costume3", "./Bounce/costumes/costume3.svg", { x: 0, y: 0 }),
      new Costume("costume4", "./Bounce/costumes/costume4.svg", {
        x: 169.43717162872156,
        y: 127.8676859555014
      }),
      new Costume("costume5", "./Bounce/costumes/costume5.svg", {
        x: 167.78972604203153,
        y: -142.65180749708105
      }),
      new Costume("costume6", "./Bounce/costumes/costume6.svg", {
        x: -190.625,
        y: 96.00000000000027
      }),
      new Costume("costume7", "./Bounce/costumes/costume7.svg", {
        x: 202.375,
        y: 215.3750000000001
      }),
      new Costume("costume8", "./Bounce/costumes/costume8.svg", {
        x: 231.375,
        y: 132.67837086242707
      }),
      new Costume("costume9", "./Bounce/costumes/costume9.svg", {
        x: 108.17683681658568,
        y: 6.722584705619312
      }),
      new Costume("costume10", "./Bounce/costumes/costume10.svg", {
        x: 65.46067987740804,
        y: -157.49362631542073
      }),
      new Costume("costume11", "./Bounce/costumes/costume11.svg", {
        x: 0,
        y: 0
      })
    ];

    this.sounds = [new Sound("pop", "./Bounce/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenGreenFlagClicked() {
    this.effects.fisheye = 0;
    while (true) {
      this.costume = this.stage.vars.level;
      this.goto(0, 0);
      yield;
    }
  }
}
