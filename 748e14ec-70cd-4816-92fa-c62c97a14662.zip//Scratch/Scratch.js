/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Scratch extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("cat locked", "./Scratch/costumes/cat locked.svg", {
        x: 17.29687677796923,
        y: 25.124999060800945
      }),
      new Costume(
        "Cat unlocked closed",
        "./Scratch/costumes/Cat unlocked closed.svg",
        { x: 17.296875, y: 25.125 }
      ),
      new Costume("costume1", "./Scratch/costumes/costume1.svg", {
        x: 17.296864999999997,
        y: 28.875
      }),
      new Costume("costume2", "./Scratch/costumes/costume2.svg", {
        x: 17.296864999999997,
        y: 32.625
      }),
      new Costume("costume3", "./Scratch/costumes/costume3.svg", {
        x: 17.296864999999997,
        y: 36.375
      }),
      new Costume("costume4", "./Scratch/costumes/costume4.svg", {
        x: 17.296864999999997,
        y: 40.125
      }),
      new Costume("costume5", "./Scratch/costumes/costume5.svg", {
        x: 17.296864999999997,
        y: 43.875
      }),
      new Costume("costume6", "./Scratch/costumes/costume6.svg", {
        x: 17.296864999999997,
        y: 47.625
      }),
      new Costume("costume7", "./Scratch/costumes/costume7.svg", {
        x: 17.296864999999997,
        y: 51.375
      }),
      new Costume("costume8", "./Scratch/costumes/costume8.svg", {
        x: 17.296864999999997,
        y: 55.125
      }),
      new Costume("costume9", "./Scratch/costumes/costume9.svg", {
        x: 17.296864999999997,
        y: 58.875
      }),
      new Costume(
        "Cat unlocked free",
        "./Scratch/costumes/Cat unlocked free.svg",
        { x: 17.671865000000025, y: 63.375 }
      ),
      new Costume("costume10", "./Scratch/costumes/costume10.svg", {
        x: 33.09375177796926,
        y: 15.371945103798623
      }),
      new Costume("costume11", "./Scratch/costumes/costume11.svg", {
        x: 14.697149690819515,
        y: 15.371942085995414
      }),
      new Costume("costume12", "./Scratch/costumes/costume12.svg", {
        x: 14.697147345409775,
        y: 15.371941042997719
      })
    ];

    this.sounds = [new Sound("Meow", "./Scratch/sounds/Meow.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    while (!(this.toNumber(this.stage.vars.level) === 11)) {
      yield;
    }
    this.goto(172, -110);
    this.costume = "cat locked";
    this.visible = true;
    while (!(this.costumeNumber === 13)) {
      yield* this.wait(0.1);
      this.costumeNumber++;
      yield;
    }
    yield* this.wait(1);
    for (let i = 0; i < 2; i++) {
      this.costumeNumber++;
      yield;
    }
    yield* this.wait(5);
    this.broadcast("Hj");
  }
}
