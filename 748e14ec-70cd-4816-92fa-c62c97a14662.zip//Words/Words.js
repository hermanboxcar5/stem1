/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Words extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Words/costumes/costume1.svg", {
        x: 139.3749958691406,
        y: 208
      }),
      new Costume("costume2", "./Words/costumes/costume2.svg", {
        x: 137.375,
        y: 253
      }),
      new Costume("costume3", "./Words/costumes/costume3.svg", { x: 0, y: 0 }),
      new Costume("costume4", "./Words/costumes/costume4.svg", {
        x: 147.375,
        y: 247
      }),
      new Costume("costume5", "./Words/costumes/costume5.svg", { x: 0, y: 0 }),
      new Costume("costume6", "./Words/costumes/costume6.svg", {
        x: 38.625,
        y: 184.75
      }),
      new Costume("costume7", "./Words/costumes/costume7.svg", {
        x: 212.625,
        y: -103.25
      }),
      new Costume("costume8", "./Words/costumes/costume8.svg", { x: 0, y: 0 }),
      new Costume("costume10", "./Words/costumes/costume10.svg", {
        x: 0,
        y: 0
      }),
      new Costume("costume9", "./Words/costumes/costume9.svg", { x: 0, y: 0 }),
      new Costume("costume11", "./Words/costumes/costume11.svg", { x: 0, y: 0 })
    ];

    this.sounds = [new Sound("pop", "./Words/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      this.moveAhead();
      this.costume = this.stage.vars.level;
      this.goto(0, 0);
      yield;
    }
  }
}
