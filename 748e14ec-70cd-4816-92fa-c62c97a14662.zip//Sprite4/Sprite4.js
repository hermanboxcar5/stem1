/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite4 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite4/costumes/costume1.svg", {
        x: 243.86241273204905,
        y: 111.05199309106831
      })
    ];

    this.sounds = [new Sound("pop", "./Sprite4/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "MENU.ON" },
        this.whenIReceiveMenuOn
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "MENU.OFF" },
        this.whenIReceiveMenuOff
      )
    ];

    this.audioEffects.volume = 0;
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    while (true) {
      this.goto(0, 0);
      yield;
    }
  }

  *whenthisspriteclicked() {
    this.broadcast("Mt");
  }

  *whenIReceiveMenuOn() {
    this.visible = true;
  }

  *whenIReceiveMenuOff() {
    this.visible = false;
  }
}
