/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Bad extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Bad/costumes/costume1.svg", { x: 0, y: 0 }),
      new Costume("costume2", "./Bad/costumes/costume2.svg", {
        x: 13.871854999999982,
        y: -83.81482000000005
      }),
      new Costume("costume3", "./Bad/costumes/costume3.svg", {
        x: 342.87642500000004,
        y: -116.8196147110333
      }),
      new Costume("costume4", "./Bad/costumes/costume4.svg", {
        x: 29.49181999999999,
        y: 123.15999
      }),
      new Costume("costume5", "./Bad/costumes/costume5.svg", {
        x: 175.43821015541,
        y: -155.35947951666924
      }),
      new Costume("costume6", "./Bad/costumes/costume6.svg", {
        x: 117.73046299624636,
        y: 95.21103763593125
      }),
      new Costume("costume7", "./Bad/costumes/costume7.svg", {
        x: 52.61093603603604,
        y: 128.54853
      }),
      new Costume("costume8", "./Bad/costumes/costume8.svg", {
        x: 156.90891,
        y: 41.75
      }),
      new Costume("costume9", "./Bad/costumes/costume9.svg", {
        x: 250.49972,
        y: 195.25
      }),
      new Costume("costume10", "./Bad/costumes/costume10.svg", {
        x: 185.14289441176464,
        y: 36.009948096885836
      }),
      new Costume("costume11", "./Bad/costumes/costume11.svg", { x: 0, y: 0 })
    ];

    this.sounds = [new Sound("pop", "./Bad/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenGreenFlagClicked() {
    this.effects.fisheye = 0;
    this.moveBehind();
    while (true) {
      this.costume = this.stage.vars.level;
      this.goto(0, 0);
      yield;
    }
  }
}
