/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Ground extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Ground/costumes/costume1.svg", {
        x: 306.399024024024,
        y: -99.94594594594594
      }),
      new Costume("costume2", "./Ground/costumes/costume2.svg", {
        x: 253.375,
        y: 72.75
      }),
      new Costume("costume3", "./Ground/costumes/costume3.svg", {
        x: 257.375,
        y: 89.75000000000007
      }),
      new Costume("costume4", "./Ground/costumes/costume4.svg", {
        x: 244.375,
        y: 165
      }),
      new Costume("costume5", "./Ground/costumes/costume5.svg", {
        x: 243.375,
        y: -140.25
      }),
      new Costume("costume6", "./Ground/costumes/costume6.svg", {
        x: 251.75,
        y: 132.125
      }),
      new Costume("costume7", "./Ground/costumes/costume7.svg", {
        x: 249.37499499999998,
        y: 134.916645
      }),
      new Costume("costume8", "./Ground/costumes/costume8.svg", {
        x: 260.375,
        y: 229.00000000000006
      }),
      new Costume("costume9", "./Ground/costumes/costume9.svg", {
        x: 490.375,
        y: 3.000000000000057
      }),
      new Costume("costume10", "./Ground/costumes/costume10.svg", {
        x: 250.375,
        y: 78.75
      }),
      new Costume("costume11", "./Ground/costumes/costume11.svg", {
        x: 267.375,
        y: -138
      })
    ];

    this.sounds = [new Sound("pop", "./Ground/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenGreenFlagClicked() {
    this.effects.fisheye = 0;
    this.restartTimer();
    while (true) {
      this.costume = this.stage.vars.level;
      this.goto(0, 0);
      yield;
    }
  }
}
