/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite2/costumes/costume1.svg", {
        x: 242.33877,
        y: 199.5
      }),
      new Costume("costume2", "./Sprite2/costumes/costume2.svg", {
        x: 242.33877,
        y: 181.56086
      })
    ];

    this.sounds = [new Sound("pop", "./Sprite2/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "MENU.ON" },
        this.whenIReceiveMenuOn
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "MENU.OFF" },
        this.whenIReceiveMenuOff
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];
  }

  *whenGreenFlagClicked() {
    this.costume = "costume1";
  }

  *whenthisspriteclicked() {
    if (this.costumeNumber === 1) {
      this.costume = "costume2";
      this.broadcast("MENU.ON");
    } else {
      this.costume = "costume1";
      this.broadcast("MENU.OFF");
    }
  }

  *whenIReceiveMenuOn() {
    this.stage.vars.mode = 2;
    this.costume = "costume2";
  }

  *whenIReceiveMenuOff() {
    this.stage.vars.mode = 1;
    this.costume = "costume1";
  }

  *whenGreenFlagClicked2() {
    while (true) {
      this.goto(0, 0);
      yield;
    }
  }
}
